import { Routes, RouterModule } from '@angular/router';
import { ProductAddComponent } from './components/product-add/product-add.component';
import { ProductListComponent } from './components/product-list/product-list.component';
import { ProductEditComponent } from './components/product-edit/product-edit.component';
import { ProductViewComponent } from './components/product-view/product-view.component';
import { NgModule } from '@angular/core';

const productRoutes: Routes = [
    {
        path: 'products', component: ProductListComponent
    },
    {
        path: 'view/:id', component: ProductViewComponent
    },
    {
        path: 'add', component: ProductAddComponent
    },
    {
        path: 'edit/:id', component: ProductEditComponent
    }
];
@NgModule({
    imports: [RouterModule.forRoot(productRoutes)],
    exports: [RouterModule]
})
export class ProductRoutingModule {

}
