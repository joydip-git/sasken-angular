import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { ProductRoutingModule } from './product-routing.module';
import { ProductFilterPipe } from './pipes/product-filter.pipe';
import { ProductService } from './services/product.service';

import { ProductListComponent } from './components/product-list/product-list.component';
import { ProductAddComponent } from './components/product-add/product-add.component';
import { ProductEditComponent } from './components/product-edit/product-edit.component';
import { ProductViewComponent } from './components/product-view/product-view.component';
import { StarComponent } from '../common/star/star.component';

@NgModule({
    declarations: [
        ProductListComponent,
        ProductAddComponent,
        ProductFilterPipe,
        StarComponent,
        ProductViewComponent,
        ProductEditComponent
    ],
    imports: [
        BrowserModule,
        HttpClientModule,
        FormsModule,
        ProductRoutingModule
    ],
    exports: [ProductListComponent],
    providers: [ProductService]
})
export class ProductModule {

}
