import { Component, OnInit, OnDestroy } from '@angular/core';
import { Product } from '../../models/product.model';
import { ProductService } from '../../services/product.service';
import { Subscription } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ResponseStatus } from '../../models/reponse-status.model';

@Component({
    templateUrl: './product-edit.component.html',
    styleUrls: ['./product-edit.component.scss']
})

export class ProductEditComponent implements OnInit, OnDestroy {

    product: Product;
    productSubscription: Subscription;
    productEditSubscription: Subscription;
    errorMessage: string;

    constructor(private productService: ProductService, private currentRoute: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        const allParams = this.currentRoute.params;
        this.productSubscription =
            allParams
                .pipe(switchMap((ps: Params) =>
                    this.productService.getProduct(+ps['id'])))
                .subscribe(
                    (p: Product) => this.product = p,
                    (err) => this.errorMessage = err
                );
    }

    submitData(productData, id: number) {
        console.log(productData);
        this.productEditSubscription =
            this.productService
                .updateProduct({
                    productId: id,
                    price: productData.price,
                    productName: productData.productName,
                    description: productData.description,
                    productCode: productData.productCode,
                    releaseDate: productData.releaseDate,
                    starRating: productData.starRating,
                    imageUrl: productData.imageUrl
                })
                .subscribe(
                    (rsp: ResponseStatus) => console.log(rsp.message),
                    (err) => console.log(err),
                    () => this.router.navigate(['/products'])
                );
    }

    ngOnDestroy() {
        if (this.productSubscription) {
            this.productSubscription.unsubscribe();
        }
        if (this.productEditSubscription) {
            this.productEditSubscription.unsubscribe();
        }
    }
}
