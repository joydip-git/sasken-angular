import { Component, OnDestroy } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { ResponseStatus } from '../../models/reponse-status.model';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
    templateUrl: './product-add.component.html',
    styleUrls: ['./product-add.component.scss']
})

export class ProductAddComponent implements OnDestroy {

    productAddSubscription: Subscription;

    constructor(private ps: ProductService, private loc: Location, private router: Router) {

    }

    submitData(productData) {
        this.productAddSubscription =
            this.ps
                .addProduct({
                    productId: productData.productId,
                    price: productData.price,
                    productName: productData.productName,
                    description: productData.description,
                    productCode: productData.productCode,
                    releaseDate: productData.releaseDate,
                    starRating: productData.starRating,
                    imageUrl: productData.imageUrl
                })
                .subscribe(
                    (rsp: ResponseStatus) => console.log(rsp.message),
                    (err) => console.log(err),
                    () => this.router.navigate(['/products'])
                    // () => this.loc.go('http://localhost:4200/products')
                );
    }

    ngOnDestroy() {
        if (this.productAddSubscription) {
            this.productAddSubscription.unsubscribe();
        }
    }
}
