import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ProductService } from '../../services/product.service';
import { Product } from '../../models/product.model';

@Component({
  templateUrl: './product-view.component.html',
  styleUrls: ['./product-view.component.scss']
})
export class ProductViewComponent implements OnInit {

  product: Product;
  constructor(private currentRoute: ActivatedRoute, private svc: ProductService, private router: Router) { }

  ngOnInit() {
    let pid: number;

    const obsParams: Observable<Params> = this.currentRoute.params;
    obsParams.subscribe(
      (ps: Params) => {
        pid = +ps['id'];
        this.svc.getProduct(pid).subscribe(
          (p: Product) => this.product = p,
          (e) => console.log(e));
      },
      (err) => console.log(err));

  }
  goBack() {
    this.router.navigate(['/products']);

  }
}
