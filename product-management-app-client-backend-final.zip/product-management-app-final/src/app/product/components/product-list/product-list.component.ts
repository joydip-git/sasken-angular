import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit, OnChanges } from '@angular/core';
import { Product } from '../../models/product.model';
import { ProductService } from '../../services/product.service';
import { Observable, Subscription, Subject } from 'rxjs';
import { ResponseStatus } from '../../models/reponse-status.model';
import { StarComponent } from 'src/app/common/star/star.component';

@Component({
    selector: 'app-product-list',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit, OnDestroy, AfterViewInit, OnChanges {

    products: Product[];
    productSubscription: Subscription;
    deleteSubscription: Subscription;
    updateSubscription: Subscription;

    // @ViewChild(StarComponent, null) star = new Subject<StarComponent>();
    // @ViewChild(StarComponent, null) star: StarComponent;
    filterText = '';
    statusMessage: string;
    constructor(private productService: ProductService) {

    }
    ngOnInit() {
        console.log('plist init');
        this.loadData();

    }
    ngOnChanges() {
        console.log('plist on change');
    }
    ngAfterViewInit() {
        // this.star.next();
        // this.star.updateRating();
    }
    ngOnDestroy() {
        console.log('plist destroyed');
        if (this.productSubscription) {
            this.productSubscription.unsubscribe();
        }

        if (this.deleteSubscription) {
            this.deleteSubscription.unsubscribe();
        }

        if (this.updateSubscription) {
            this.updateSubscription.unsubscribe();
        }
    }

    deleteProduct(productId: number) {
        this.deleteSubscription = this.productService
            .deleteProduct(productId)
            .subscribe(
                (status: ResponseStatus) => {
                    this.statusMessage = status.message;
                    this.products = status.data;
                },
                (err) => this.statusMessage = err
            );
    }

    private loadData() {
        const productObs: Observable<Product[]>
            = this.productService.getProducts();
        this.productSubscription = productObs.subscribe(
            (prodArray: Product[]) => this.products = prodArray,
            (err: any) => console.log(err)
        );
    }
    changeRating(newRating: number, p: Product) {
        p.starRating = newRating;
        this.updateSubscription = this.productService.updateProduct(p).subscribe(
            (resp: ResponseStatus) => {
                this.statusMessage = resp.message;
                this.products = resp.data;
            },
            (err) => {
                this.statusMessage = err;
            });
    }
}
