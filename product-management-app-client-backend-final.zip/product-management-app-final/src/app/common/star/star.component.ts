import { Component, OnInit, Input, EventEmitter, Output, OnChanges } from '@angular/core';

@Component({
  selector: 'app-star',
  templateUrl: './star.component.html',
  styleUrls: ['./star.component.scss']
})
export class StarComponent implements OnInit, OnChanges {

  // tslint:disable-next-line: no-input-rename
  @Input('ratingValue') rating: number;
  @Output() ratingChanged = new EventEmitter<number>();
  starWidth: number;
  constructor() { }

  ngOnInit() {

  }
  ngOnChanges() {
    console.log(this.rating);
    this.starWidth = this.rating * (71.5 / 5);
  }
  updateRating() {
    const newRating = +(prompt('provide new rating: ', this.rating.toString()));
    console.log(newRating);
    this.ratingChanged.emit(newRating);
  }
}
