export interface ResponseStatus {
    message: string;
}