import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Product } from '../models/product.model';
import { ResponseStatus } from '../models/reponse-status.model';

@Injectable()
export class ProductService {

    url = 'http://localhost:8081/productservice';

    constructor(private http: HttpClient) {

    }

    public getProducts(): Observable<Product[]> {

        // const productObservable: Observable<Product[]> =
        //     this.http.get<Product[]>(this.url);

        return this.http
            .get(this.url)
            .pipe(map(respBody => respBody as Product[]));

    }

    public getProduct(productId: number): Observable<Product> {
        return this.http.get<Product>(`${this.url}/${productId}`);
    }

    public addProduct(product: Product): Observable<ResponseStatus> {
        return this.http.post<ResponseStatus>(this.url, product);
    }

    public deleteProduct(productId: number): Observable<ResponseStatus> {
        return this.http.delete<ResponseStatus>(`${this.url}/${productId}`);
    }

    public updateProduct(product: Product): Observable<ResponseStatus> {
        return this.http.put<ResponseStatus>(this.url, product);
    }
}
