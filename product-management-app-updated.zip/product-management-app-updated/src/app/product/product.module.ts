import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { ProductListComponent } from './components/product-list/product-list.component';
import { ProductService } from './services/product.service';
import { ProductAddComponent } from './components/product-add/product-add.component';
import { ProductFilterPipe } from './pipes/product-filter.pipe';

@NgModule({
    declarations: [ProductListComponent, ProductAddComponent, ProductFilterPipe],
    imports: [BrowserModule, HttpClientModule, FormsModule],
    exports: [ProductListComponent],
    providers: [ProductService]
})
export class ProductModule {

}
