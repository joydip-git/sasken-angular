import { Component, OnInit, OnDestroy, OnChanges } from '@angular/core';
import { Product } from '../../models/product.model';
import { ProductService } from '../../services/product.service';
import { Observable, Subscription } from 'rxjs';
import { ResponseStatus } from '../../models/reponse-status.model';

@Component({
    selector: 'app-product-list',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit, OnDestroy {

    products: Product[];
    productSubscription: Subscription;
    filterText = '';
    statusMessage: string;
    constructor(private productService: ProductService) {

    }

    ngOnInit() {
        this.loadData();
    }
    // ngOnChanges() {
    //     this.loadData();
    // }

    ngOnDestroy() {
        this.productSubscription.unsubscribe();
    }

    deleteProduct(productId: number) {
        this.productService
            .deleteProduct(productId)
            .subscribe(
                (msg: ResponseStatus) => this.statusMessage = msg.message,
                (err) => this.statusMessage = err,
                () => this.loadData()
            );
    }
    // private success(prodArray: Product[]) {
    //     this.products = prodArray;
    // }
    // private failure(err: any) {
    //     console.log(err);
    // }

    private loadData() {
        const productObs: Observable<Product[]>
            = this.productService.getProducts();
        // productObs.subscribe(this.success, this.failure);
        this.productSubscription = productObs.subscribe(
            (prodArray: Product[]) => this.products = prodArray,
            (err: any) => console.log(err)
        );
    }
}
